#ifndef _WSN_COMPONENTS_LCA_SENSOR_
#define _WSN_COMPONENTS_LCA_SENSOR_

#include <vector>
#include <map>
#include <string>
#include <iostream>
#include <sstream>
#include <math.h>
#include <random.h>
#include "packet.h"
#include "hdr_components.h"
#include <mobilenode.h>
#include "agent.h"

using namespace std;

class WSN_ComponentsSensor;

enum SensorRole {
	UNKNOWN, EB,
	CH,
	CM,
	INI, GWR, CHC,
	GW, EXT
};

class WSN_ComponentsSensor {

public: 
	void setAgent(Agent *);
	void setSensorId(int);
	std::map<string, int> GetCHElectionParams();
	std::map<string, int> GetJoinParams();

	void init(int, double);

	SensorRole role;

	void AddNeighbor(SensorDataParams);
	void getNeighbors();
	void AddProbe(SensorDataParams);
	void DiscoverNeighbor();
	void ACKDiscoverNeighbor();

	void AddCandidateCH(SensorDataParams);
	void AddCandidateMember(SensorDataParams);
	void CommandPrintCandidateCH();
	void CommandPrintCandidateMembers();
	void CommandPrintCHs();
	void resendstartflooding(WSN_Components_Message*);

	bool contains(int addr, vector<int> v){
		for(vector<int>::iterator i = v.begin(); i != v.end(); i++){
			if((*i) == addr){     
				return true;
			}
		}
		return false; 
	}

	bool contains(int addr, vector<SensorDataParams> v){
		for(vector<SensorDataParams>::iterator i = v.begin(); i != v.end(); i++){
			if((*i).id == addr){     
				return true;
			}
		}
		return false; 
	}

	bool isfloodingsent(int uid){
		for (list<int>::iterator i = lstpktflooding.begin(); i != lstpktflooding.end(); i++){
			if ((*i) == uid){
				return true;
			}
		}
		return false;
	}

	void resetfloodingsent() { lstpktflooding.clear(); }

	void addfloodingsent(int uid){
		lstpktflooding.push_front(uid);
	}
	
	vector<SensorDataParams> getVecCandidateCH() { return vecCandidateCH; }
	vector<SensorDataParams> getVecCandidateMembers() { return vecCandidateMembers; }
	vector<SensorDataParams> getVecRecvProbeMsg() { return vecRecvProbeMsg; }
	vector<SensorDataParams> getVecNeighbors() { return vecNeighbors;	}
	list<int> lstpktflooding;

	int getSensorId() {
		return sensorId;
	}

	// sensor coordinators
	int getX()  { return coordX; }
	int getY() { return coordY; }
	int getZ()  { return coordZ; }
	void setX(int latitude)  { coordX = latitude; }
	void setY(int longitude) { coordY = longitude; }
	void setZ(int altitude)  { coordZ = altitude; }
	void setCoords(int lat, int lon, int alt) {
		coordX = lat;
		coordY = lon;
		coordZ = alt;
	}
	double getReadings() { return readings[0]; }
    void setReadings(double *read) 
    {
        readings = (double *) malloc (numReadings * sizeof(double));
        for (int i=0; i < numReadings; i++)
            readings[i] = read[i];

    }

    double getCHReading() { return CHreading; }
    void setCHReading(double read) {CHreading = read;}

    int getNumReadings() { return numReadings; }
    void setNumReadings(int numRead) {numReadings = numRead;}

	int getNumSensors() { return numSensors; }
	MsgID lastMsg;
    vector<SensorDataParams> vecNeighbors;
    vector<int> vecCHNeighbors;
    double threshold;
    int energia;
    int pID;
	vector<SensorDataParams> vecRecvProbeMsg;

private:
	Agent *agent_;
	int sensorId;

	// Neighbors
	
	

	//CandidateCH
	vector<SensorDataParams> vecCandidateCH;
	vector<SensorDataParams> vecCandidateMembers;


	int coordX;
	int coordY;
	int coordZ;
    double *readings; 
    double CHreading;
    int numReadings;
    int numSensors;

};

#endif
