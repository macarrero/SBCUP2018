#ifndef _WSN_COMPONENTS_LCA_
#define _WSN_COMPONENTS_LCA_

#include <mobilenode.h>
#include "componentsDCSSCCH.h"
#include "componentsDCSSCCM.h"
#include "componentsDCSSCSensor.h"
#include "componentsLib.h"
#include "componentsRead.h"
#include "agent.h"
#include "packet.h"
#include "address.h"
#include "tclcl.h"
#include "ip.h"

using namespace std;

class WSN_ComponentsAgent;

typedef struct{
	int pktid;
} pktflooding;

enum RoundCmd {
    TWAIT,
    TREQ,
    TADV,
    TEXT,
    CLUSTER_FORMATION,
	DISCOVER_NEIGHBORS,
	ACK_DISCOVER_NEIGHBORS,	
	SELECT_CH,
	JOIN_CLUSTER,
	FINISH
};

class WSN_ComponentsAgent: public Agent {
	friend class RtxComponentTimer;

	friend class ClusterDefinitionTimer;
	int numSensors_;
	
public:
	WSN_ComponentsAgent();
	SensorRole role;
	int** neighboringMatrix;
	void createneighboringMatrix(int, int);
	void SendPkt(MsgID, WSN_Components_Message *);
	void AddFloodingSent(int);
	void AddTwoHopNeighbor(int);
	bool IsFloodingSent(int);
	void CommandInit(const char*const* argv);
    void CommandRead(const char*const* argv);
    void CommandClusterFormation();
	void CommandPosition(const char*const* argv);
	void CommandDiscoverNeighbors();
	void CommandSelectCH();
	void CommandGetNeighbors();
	void CommandPrint(const char*);
	void CommandPing();
	void ResetTimer();
	void InitTimer(double);
    void TimerTadv(double,double);
    void TimerTwait();
    void TimerTreq();
    void TimerText();
	void TimerHandle(RoundCmd);
	inline Packet* getNewPkt() { return allocpkt(); }
	void setLastMsg(MsgID);
	MsgID getLastMsg();
	virtual void recv (Packet *, Handler *);
	virtual int command(int, const char*const*);
	//RoundCommand roundCmd;
    RoundCmd round;

	WSN_ComponentsSensor* getCompSensor() { return compSensor; }
	WSN_Timer getLibTimer() { return libTimer; }


protected:
	MobileNode *node;
	Trace *tracetarget;
	int myaddr;
	MsgID lastMsg;
	list<pktflooding> lstPktFlooding;
	vector<int> vecNeighbors;
	list<int> lstTwoHopNeighbors;
	WSN_Timer libTimer;

private:
	WSN_ComponentsSensor *compSensor;
	WSN_ComponentsCH *compCH;
	WSN_ComponentsCM *compCM;
	WSN_ComponentsLib compLib;
    WSN_Read *compRead;

	vector<SensorDataParams> vecSensorDataParams;

};

#endif
