#ifndef _WSN_COMPONENTS_READ_
#define _WSN_COMPONENTS_READ_

#include<string.h>
#include<stdio.h>
#include<stdlib.h>
#include<string.h>

class WSN_Read {

public:
	WSN_Read() 
    { 

    }
	
public:

    double *getReading(int id, FILE *f, int *numReadings)
	{  
        int cont = 0;
        char row[100];

        while (cont < id && !feof(f))
        {
           fgets(row, 100, f);  
           cont++;  
        }
  
        char *str;
        str = strtok(row, " ");
        *numReadings = atoi(str);

        double *read;
        read = (double *) malloc(*numReadings * sizeof(double));
        int i = 0;
        while (i < *numReadings)
        {
            str = strtok(NULL, " ");
            read[i] = atof(str);
            i++;
        }
           
        fclose(f);
        return read;
	}
};

#endif
