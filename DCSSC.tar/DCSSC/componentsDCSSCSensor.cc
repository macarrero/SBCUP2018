#include "componentsDCSSCSensor.h"
#include "componentsDCSSC.h"

using namespace std;

#define CURRENT_TIME    Scheduler::instance().clock()

void WSN_ComponentsSensor::setAgent(Agent *agent) {
	this->agent_ = dynamic_cast<WSN_ComponentsAgent*>(agent);
}

void WSN_ComponentsSensor::setSensorId(int id) {
	sensorId = id;
}

std::map<string, int> WSN_ComponentsSensor::GetCHElectionParams() {
	std::map<string, int> mapUID;
	std::string id=("ID");

	if (lastMsg == CH_ANNOUNCE) return mapUID;

	if (vecCHNeighbors.size() >0) {
		for ( int j = 0; j < vecCHNeighbors.size(); j++ ) {
			int uid = vecCHNeighbors.at(j);
				string newId = static_cast<std::ostringstream*>( &(ostringstream() << uid) )->str();
				mapUID.insert(std::pair<string, int> (id.append(id), uid));
		}

	}

	return mapUID;
}

std::map<string, int> WSN_ComponentsSensor::GetJoinParams() {
	vector<SensorDataParams> vecCandidateCH = getVecCandidateCH();
	std::map<string, int> mapCandidateCH;

	if (vecCandidateCH.size() > 0) {
		SensorDataParams sdp = vecCandidateCH.at(0);
		std::string id=("ID");
		mapCandidateCH.insert(std::pair<string, int> (id.append(id), sdp.id));

		for ( int j = 1; j < vecCandidateCH.size(); j++ ) {
			sdp = vecCandidateCH.at(j);
			string newId = static_cast<std::ostringstream*>( &(ostringstream() << sdp.id) )->str();
			mapCandidateCH.insert(std::pair<string, int> (id.append(id), sdp.id));
		}
		return mapCandidateCH;
	}
}

void WSN_ComponentsSensor::init(int numSensors, double threshold) {
	this->numSensors=numSensors;
    this->threshold = threshold;
    role = INI;
}

void WSN_ComponentsSensor::AddNeighbor(SensorDataParams sensorDataParams) {
	if (!contains(sensorDataParams.id, vecNeighbors)) {
		vecNeighbors.push_back(sensorDataParams);
	}
}

void WSN_ComponentsSensor::AddProbe(SensorDataParams sensorDataParams) {
	if (!contains(sensorDataParams.id, vecRecvProbeMsg))
		vecRecvProbeMsg.push_back(sensorDataParams);
}

void WSN_ComponentsSensor::AddCandidateCH(SensorDataParams sensorDataParams) {
	if (!contains(sensorDataParams.id, vecCandidateCH)) {
		vecCandidateCH.push_back(sensorDataParams);
	}
}

void WSN_ComponentsSensor::AddCandidateMember(SensorDataParams sensorDataParams) {
	if (!contains(sensorDataParams.id, vecCandidateMembers)) {
		vecCandidateMembers.push_back(sensorDataParams);
	}
}

void WSN_ComponentsSensor::resendstartflooding(WSN_Components_Message* param){
	WSN_ComponentsAgent* agent = dynamic_cast<WSN_ComponentsAgent*>(agent_);
	SensorDataParams sp;
	MsgParam newp;

	param->setId(param->getHdrWsnComp()->uid);
	param->getHdrCmn()->uid_ = 1;
	param->setNextHop(IP_BROADCAST);
	param->setAddressType(NS_AF_INET);
	param->setDirection(hdr_cmn::DOWN);		// packet direction
	param->setPrevHop(getSensorId());
	param->setHop();

	sp.id = param->getId();
	newp.size = 1;
	newp.msgParam[0] = sp;

	agent->SendPkt(param->getMsgId(), param);
	addfloodingsent(param->getHdrWsnComp()->uid);
}

void WSN_ComponentsSensor::getNeighbors() {
	printf("\nVecNeig de %d (%f): ", getSensorId(), CURRENT_TIME);
	for (vector<SensorDataParams>::iterator i = vecNeighbors.begin(); i != vecNeighbors.end(); i++) {
		printf("id %d - energia %d\n",(*i).id, (*i).energia);
	}

}

void WSN_ComponentsSensor::CommandPrintCandidateCH() {
	printf("\nCandidateCH de %d (%f): ", getSensorId(), CURRENT_TIME);
	for (vector<SensorDataParams>::iterator i = vecCandidateCH.begin(); i != vecCandidateCH.end(); i++) {
		printf("%d ",(*i).id);
	}
}

void WSN_ComponentsSensor::CommandPrintCandidateMembers() {
	printf("\nCandidateMembers de %d (%f): ", getSensorId(), CURRENT_TIME);
	for (vector<SensorDataParams>::iterator i = vecCandidateMembers.begin(); i != vecCandidateMembers.end(); i++) {
		printf("%d ",(*i).id);
	}
}

void WSN_ComponentsSensor::CommandPrintCHs() {
	if (this->role == CH)
		printf("\nCH %d (%f): ", getSensorId(), CURRENT_TIME);
}
