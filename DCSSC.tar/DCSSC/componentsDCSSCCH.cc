#include <string>
#include "componentsDCSSCCH.h"
#include "componentsDCSSC.h"

using namespace std;

#define CURRENT_TIME    Scheduler::instance().clock()

WSN_ComponentsCH::WSN_ComponentsCH() {}

WSN_ComponentsCH::WSN_ComponentsCH(Agent *agent) {
	compLib = new WSN_ComponentsLib();
	this->agent_ = dynamic_cast<WSN_ComponentsAgent*>(agent);
}

void WSN_ComponentsCH::setAgent(Agent *agent) {
	this->agent_ = dynamic_cast<WSN_ComponentsAgent*>(agent);
}

template <class K, class V> void WSN_ComponentsCH::SelectCH(std::map<K, V> similaridade) {
	WSN_ComponentsAgent* agent = dynamic_cast<WSN_ComponentsAgent*>(agent_);
	SensorDataParams sp;
	MsgParam newp;
	Packet* pkt = agent->getNewPkt();
	WSN_Components_Message param(pkt);

    double s = similaridade.at("K");

	if (s <= agent->getCompSensor()->threshold) //se altamente correlacionados
    {
        printf("Altamente correlacionado\n");
        agent->getCompSensor()->role = CHC;
        double energy = agent->getCompSensor()->energia;
        double energyNBR = 0;
        int nbr = 0;
        for (vector<SensorDataParams>::iterator i = agent->getCompSensor()->vecNeighbors.begin(); i != agent->getCompSensor()->vecNeighbors.end(); i++) {
            energyNBR += (*i).energia;
            nbr++;
        }
        int alfa = 1;
        double res = (energy + energyNBR)/(energy * (nbr+1));
        res = res * alfa;
        printf("Nbr: %d Re(%d): %f\n", nbr, agent->getCompSensor()->getSensorId(), res); 
        //faz broadcast de CHADV quando expirar
        double minAdv = 0;

        agent->TimerTadv(minAdv,res);
        agent->round = TADV;
        agent->getCompSensor()->role = CH;
        printf("SELECT_CH - sou CH %d (%f)\n", agent->getCompSensor()->getSensorId(), CURRENT_TIME);
    }
}

template void WSN_ComponentsCH::SelectCH(std::map<string, double>);
