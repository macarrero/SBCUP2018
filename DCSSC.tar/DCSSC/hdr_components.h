#ifndef _HDR_WSN_COMPONENTS_H_
#define _HDR_WSN_COMPONENTS_H_

#include <list>
#include <vector>
#include <algorithm>
#include "packet.h"
#include "ip.h"

enum MsgID {
	SENSOR_DATA,
    CFRM,
    CHREQ,
    CEXT,
    CHADV,
    ACK_CEXT,
	ACK_SENSOR_DATA,
	SENSOR_ID,
	ACK_SENSOR_ID,
	NEIGHBORS_ID,
	GET_NEIGHBORS,
	CH_ANNOUNCE,
	ACK_CH_ANNOUNCE
};

struct hdr_ping_components {
	char ping;
	double send_time;

	static int offset_;
	inline static int& offset() { return offset_; }
	inline static hdr_ping_components* access(const Packet* p) {
		return (hdr_ping_components*)p->access(offset_);
	}
};

struct SensorDataParams {
	int id;
    int energia;
	double coordX;
	double coordY;
	double coordZ;
	double reading;
    int pID;
};

typedef struct {
	int size;
	SensorDataParams msgParam[255];
} MsgParam;

struct hdr_wsn_components {
	char ping;
	char* type;
	MsgID msgID;
	MsgParam msgParams;
	int uid;
	int hop;
	double send_time;

	static int offset_;
	inline static int& offset() { return offset_; }
	inline static hdr_wsn_components* access(const Packet* p) {
		return (hdr_wsn_components*)p->access(offset_);
	}
};

class WSN_Components_Message {
public:
	Packet* pkt;
	hdr_ip* hdrip;
	hdr_cmn* cmh;
	// header
	hdr_wsn_components* hdr;

	WSN_Components_Message(Packet *p_pkt)
	{
		pkt = p_pkt;
		hdrip = hdr_ip::access(p_pkt);
		hdr = hdr_wsn_components::access(p_pkt);
		cmh = HDR_CMN(p_pkt);
		//ihp = HDR_IP(p_pkt);
	}

	inline Packet* getPkt() { return pkt; }
	inline hdr_cmn* getHdrCmn() { return cmh; }
	inline hdr_wsn_components* getHdrWsnComp() { return hdr; }
	inline void setId(int id) { hdr->uid = id; }
	inline int getId() { return hdr->uid; }
	inline void setMsgId(MsgID msgId) { hdr->msgID = msgId; }
	inline MsgID getMsgId() { return hdr->msgID; }
	inline void setHop() {hdr->hop = hdr->hop+1; }
	inline int getHop() { return hdr->hop; } 
	inline void setPrevHop(int prevHop) { cmh->prev_hop_ = prevHop; }
	inline void setNextHop(int addr) { cmh->next_hop() = addr; }
	inline void setAddressType(int addrType) { cmh->addr_type() = addrType;}
	inline void setDirection(hdr_cmn::dir_t dir) { cmh->direction() = dir; }

};

static class WSN_Components_HeaderClass : public PacketHeaderClass {
public:
	WSN_Components_HeaderClass(): PacketHeaderClass("PacketHeader/WSN_COMPONENTS", sizeof(hdr_wsn_components)) {
		bind_offset(&hdr_wsn_components::offset_);
	}
} class_hdr_wsn_components;
#endif
