#include <string>
#include <iostream>
#include <sstream>
#include <map>
#include "componentsDCSSC.h"
#include "componentsLib.h"
#include "componentsRead.h"

static int mensagens; 

int hdr_wsn_components::offset_;

#define CURRENT_TIME Scheduler::instance().clock() 

using namespace std;

static class WSN_ComponentsAgentClass : public TclClass {
public:
	WSN_ComponentsAgentClass() : TclClass("Agent/WSN_COMPONENTS") {}
	TclObject* create(int, const char*const* argv) {
		return (new WSN_ComponentsAgent());
	}
} class_WSN_COMPONENTS;

WSN_ComponentsAgent::WSN_ComponentsAgent() : Agent(PT_WSN_COMPONENTS), libTimer(this) { 
	bind("packetSize_", &size_);
	myaddr = 0;
	node = NULL;

	compSensor = new WSN_ComponentsSensor();
	compCH = new WSN_ComponentsCH();
	compCM = new WSN_ComponentsCM();
    compRead = new WSN_Read();
}

int WSN_ComponentsAgent::command(int argc, const char*const* argv) {
	if ( argc > 1 ) {
		const char* command = argv[1];
		if (strcasecmp(command, "START_WSN_COMPONENTS") == 0) {
			return TCL_OK;
		} else if (strcmp(command, "DISCOVER_NEIGHBORS") == 0) {
			CommandDiscoverNeighbors();			
			return TCL_OK;
		} else if (strcmp(command, "SELECT_CH") == 0) {
			CommandSelectCH();			
			return TCL_OK;
		} else if (strcmp(argv[1], "INIT") == 0) {
			CommandInit(argv);
			return TCL_OK;
        } else if (strcmp(argv[1], "READ") == 0) {
			CommandRead(argv);
			return TCL_OK;
		} else if (strcmp(argv[1], "CLUSTER_FORMATION") == 0) {
			CommandClusterFormation();
			return TCL_OK;
        } else if (strcmp(argv[1], "PRINT_MSG") == 0) {
            printf("Mensagens: %d\n", mensagens);
            return TCL_OK;
        } else if (strcmp(command, "PRINT") == 0) {
			const char* commandPrint = argv[2];
			CommandPrint(commandPrint);
			return TCL_OK;
		} else if (strcasecmp (argv[1], "tracetarget") == 0) {
			TclObject *obj;
			if ((obj = TclObject::lookup (argv[2])) == 0) {
				fprintf (stderr, "%s: %s lookup of %s failed\n", 
								__FILE__, argv[1], argv[2]);
				return TCL_ERROR;
			}
			tracetarget = (Trace *) obj;
			return TCL_OK;
		} else if (strcasecmp(argv[1], "port-dmux") == 0) {
			return TCL_OK;
		} else if (strcasecmp(argv[1], "node") == 0) {
			node = (MobileNode*) TclObject::lookup(argv[2]);
			return TCL_OK;
		} else if (strcasecmp(argv[1], "addr") == 0) {
			myaddr = Address::instance().str2addr(argv[2]);
			compSensor->setSensorId(myaddr);
			compSensor->setAgent(this);
			compCH->setAgent(this);
			compCM->setAgent(this);
			return TCL_OK;
		} else if(strcasecmp(argv[1],"POSITION")==0) {
			if(compSensor->getSensorId() == 0) return TCL_OK;
		 	CommandPosition(argv);

			return TCL_OK;
		}
	}
	return (Agent::command(argc, argv));
} 

void WSN_ComponentsAgent::CommandPrint(const char* p) { 
	if (strcmp(p, "GET_NEIGHBORS") == 0) 
		compSensor->getNeighbors();
	else if (strcmp(p, "CANDIDATECH") == 0)
		compSensor->CommandPrintCandidateCH(); 
	else if (strcmp(p, "MEMBERS") == 0)
		compSensor->CommandPrintCandidateMembers();
	else if (strcmp(p, "CHs") == 0)
		compSensor->CommandPrintCHs();
} 
   
void WSN_ComponentsAgent::CommandInit(const char*const* argv) {
    printf("CommandInit %d (%f)\n", compSensor->getSensorId(), CURRENT_TIME);
	compSensor->init(atoi(argv[2]), atof(argv[3]));
    if (compSensor->getSensorId() == 0)
        compSensor->role = EB;
    else
        compSensor->role = INI;
    compSensor->energia = 5;
}
  
void WSN_ComponentsAgent::CommandRead(const char*const* argv) {

    FILE *f = fopen(argv[2], "r");
    if (f == NULL) 
        printf("Erro ao abrir arquivo de leituras!\n");
    else
    {
        int *numLeituras;   
	    double *leituras = compRead->getReading(compSensor->getSensorId(), f, numLeituras);
        compSensor->setNumReadings(*numLeituras); 
        compSensor->setReadings(leituras); 
    }
} 

void WSN_ComponentsAgent::CommandDiscoverNeighbors() {
     printf("CommandDiscover %d (%f)\n", compSensor->getSensorId(), CURRENT_TIME);
	compSensor->setSensorId(myaddr);
	double r = ((double) rand() / (RAND_MAX));
    libTimer.initTimer(r*0.001);
	round = DISCOVER_NEIGHBORS;
}

void WSN_ComponentsAgent::CommandSelectCH() {
	compSensor->setSensorId(myaddr);
}
void WSN_ComponentsAgent::CommandClusterFormation() {
    printf("CommandClusterFormation %d (%f)\n", compSensor->getSensorId(), CURRENT_TIME);
    round = CLUSTER_FORMATION;
    double r = ((double) rand() / (RAND_MAX));
    libTimer.initTimer(0.001);
}

void WSN_ComponentsAgent::CommandPosition(const char*const* argv) {
	compSensor->setCoords(atoi(argv[2]), atoi(argv[3]), atoi(argv[4]));
}

void WSN_ComponentsAgent::SendPkt(MsgID msgID, WSN_Components_Message* param) {
	param->setPrevHop(compSensor->getSensorId());
	param->setNextHop(IP_BROADCAST);
	param->setAddressType(NS_AF_INET);
	param->setDirection(hdr_cmn::DOWN);

	double r = ((double) rand() / (RAND_MAX));
	Scheduler::instance().schedule(target_, param->getPkt(), (r*3));
}

void WSN_ComponentsAgent::recv(Packet* pkt, Handler *) {
	assert(initialized());
	assert(pkt);
    SensorDataParams sp;
	double Xr, Yr, Zr;
	
	WSN_Components_Message param = pkt;
    param.getPkt()->txinfo_.getNode()->getLoc(&Xr, &Yr, &Zr);

	switch(param.getMsgId())
	{
		case (SENSOR_ID):
		{
			int id = param.getHdrWsnComp()->msgParams.msgParam[0].id;

			sp.id = param.getHdrWsnComp()->msgParams.msgParam[0].id;
            sp.energia =  param.getHdrWsnComp()->msgParams.msgParam[0].energia;
			sp.coordX = param.getHdrWsnComp()->msgParams.msgParam[0].coordX; 
			sp.coordY = param.getHdrWsnComp()->msgParams.msgParam[0].coordY; 

			compSensor->AddProbe(sp);
		}
		break;
        case(CFRM):
        {
            lastMsg = CFRM;
            printf("%d recebeu CFRM de %d (%f)\n", compSensor->getSensorId(), param.getHdrCmn()->prev_hop_, CURRENT_TIME);
            if ( compSensor->role == INI ) {
				compSensor->role = GWR;
                TimerTreq();
                round = TREQ;
			}
        }
        break;
        case(CHREQ):
        {
            lastMsg = CHREQ;
            printf("%d recebeu CHREQ de %d (%f), papel %d\n", compSensor->getSensorId(),  param.getHdrCmn()->prev_hop_, CURRENT_TIME, compSensor->role);
            if ( compSensor->role == INI ) {
                compSensor->pID = param.getHdrCmn()->prev_hop_;
                int id = param.getHdrWsnComp()->msgParams.msgParam[0].id;

			    sp.id = param.getHdrWsnComp()->msgParams.msgParam[0].id;
			    sp.coordX = param.getHdrWsnComp()->msgParams.msgParam[0].coordX; 
			    sp.coordY = param.getHdrWsnComp()->msgParams.msgParam[0].coordY; 
                sp.reading = param.getHdrWsnComp()->msgParams.msgParam[0].reading;
                printf("Leitura de %d (%f)\n", param.getHdrCmn()->prev_hop_, sp.reading);
                double s1 = compSensor->getReadings();
                printf("Leitura de %d (%f)\n", compSensor->getSensorId(), s1);
                //double s1 = reading[0];
                double similaridade = fabs(s1-sp.reading); //calcula similaridade
                printf("Similaridade %f\n", similaridade);
                
                map<string, double> sim;
                sim.insert(pair<string, double> ("K", similaridade));
                compCH->SelectCH(sim);
			}
        }
        break;
        case(CHADV):
        {
            lastMsg = CHADV;
            printf("%d recebeu CHADV de %d (%f)\n", compSensor->getSensorId(), param.getHdrCmn()->prev_hop_, CURRENT_TIME);
            if (compSensor->role == INI || compSensor->role == GWR || compSensor->role == CHC ) {
				int id = param.getHdrWsnComp()->msgParams.msgParam[0].id;

			    sp.id = param.getHdrWsnComp()->msgParams.msgParam[0].id;
			    sp.coordX = param.getHdrWsnComp()->msgParams.msgParam[0].coordX; 
			    sp.coordY = param.getHdrWsnComp()->msgParams.msgParam[0].coordY; 
                sp.reading = param.getHdrWsnComp()->msgParams.msgParam[0].reading;
                sp.pID = param.getHdrWsnComp()->msgParams.msgParam[0].pID;

                printf("Leitura de %d (%f)\n", param.getHdrCmn()->prev_hop_, sp.reading);
                double s1 = compSensor->getReadings();
                printf("Leitura de %d (%f)\n", compSensor->getSensorId(), s1);

                double similaridade = fabs(s1-sp.reading); //calcula similaridade


                map<string, double> sim;
                sim.insert(pair<string, double> ("K", similaridade));
                compCM->JoinCluster(sim);
		
            }
        }
        break;
        case(CEXT):
        {
            printf("%d recebeu CEXT de %d (%f)\n", compSensor->getSensorId(), param.getHdrCmn()->prev_hop_, CURRENT_TIME);
            if ( compSensor->role == INI || compSensor->role == GWR || compSensor->role == CHC ) 
            {
				int id = param.getHdrWsnComp()->msgParams.msgParam[0].id;

			    sp.id = param.getHdrWsnComp()->msgParams.msgParam[0].id;
			    sp.coordX = param.getHdrWsnComp()->msgParams.msgParam[0].coordX; 
			    sp.coordY = param.getHdrWsnComp()->msgParams.msgParam[0].coordY; 
                sp.reading = param.getHdrWsnComp()->msgParams.msgParam[0].reading;
                sp.pID = param.getHdrWsnComp()->msgParams.msgParam[0].pID;

                double leituraCH = sp.reading;

                printf("Leitura de %d (%f)\n", param.getHdrCmn()->prev_hop_, sp.reading);
                double s1 = compSensor->getReadings();
                printf("Leitura de %d (%f)\n", compSensor->getSensorId(), s1);

                double similaridade = fabs(s1-sp.reading); //calcula similaridade

                if (similaridade <= compSensor->threshold) //se altamente correlacionados
                {
                    printf("Similaridade = %f, Treshold = %f - Altamente correlacionados\n", similaridade, compSensor->threshold);
                    SensorDataParams sp;
	                MsgParam newp;
	                Packet* pkt = getNewPkt();
	                WSN_Components_Message param(pkt);
	                param.setId(compSensor->getSensorId());
                    param.setMsgId(ACK_CEXT);
            
			        newp.size = 1;
			        sp.id = id; 
			        sp.coordX = compSensor->getX();
			        sp.coordY = compSensor->getY();
			        sp.coordZ = compSensor->getZ();

			        newp.msgParam[0] = sp;

			        param.getHdrWsnComp()->msgParams = newp;
			        SendPkt(ACK_CEXT, &param);

                    if (compSensor->role == GWR) 
                    {
                        if (sp.pID == compSensor->getSensorId())
                        {
                            compSensor->role = GW;
                            printf("%d virou GW - CH read %f\n", compSensor->getSensorId());
                            compSensor->setCHReading(leituraCH);
                            TimerText();
                            round = TEXT;
                        }                        
                        else 
                        {
                            printf("%d virou CM\n", compSensor->getSensorId());
                            compSensor->role = CM;
                            compSensor->setCHReading(leituraCH);
                            TimerText();
                            round = TEXT;
                        }
                    }
                    else {
                        compSensor->role = CM;
                        printf("%d virou CM\n", compSensor->getSensorId());
                        compSensor->setCHReading(leituraCH);
                        TimerText();
                        round = TEXT;
                    }
                }                
                else
                {
                    compSensor->role = GWR;
                    printf("%d virou GWR\n", compSensor->getSensorId());
                    TimerTreq();
                    round = TREQ;
                }			
			}
        }
        break;
        case (ACK_CEXT):
        {
            int id = param.getHdrWsnComp()->msgParams.msgParam[0].id;
            if (compSensor->getSensorId() == id && compSensor->role != EXT)
            {
                printf("%d virou EXT\n", compSensor->getSensorId());
                compSensor->role = EXT;
                round = FINISH;
            }
        }
        break;
		case (ACK_SENSOR_ID):
		{
            int size = param.getHdrWsnComp()->msgParams.size;
			
			for (int i=0; i < size; i++) {
				param.getPkt()->txinfo_.getNode()->getLoc(&Xr, &Yr, &Zr);
				if (compSensor->getSensorId() == param.getHdrWsnComp()->msgParams.msgParam[i].id) { 
					sp.id = param.getHdrCmn()->prev_hop_; // id de quem enviou a mensagem
                    sp.energia =  param.getHdrWsnComp()->msgParams.msgParam[i].energia;  
					sp.coordX = Xr; 
					sp.coordY = Yr;

					compSensor->AddNeighbor(sp);
				}
			}
		}
		break;
	}
}

void WSN_ComponentsAgent::InitTimer(double T) {
	//libTimer.resched(T);
}

template <class T>
void WSN_Timer::initTimer(T t) {
    Scheduler::instance().schedule(this, &intr, t);
}

template <class T>
void WSN_Timer::resetTimer(T t) {
    Scheduler::instance().schedule(this, &intr, t);
}

void WSN_ComponentsAgent::TimerTreq() {
    double r = ((double) rand() / (RAND_MAX));
    libTimer.resetTimer(r * 0.03);
}

void WSN_ComponentsAgent::TimerText() {
    double r = ((double) rand() / (RAND_MAX));
    libTimer.resetTimer(r * 0.03);
}


void WSN_ComponentsAgent::TimerTwait() {
    double r = ((double) rand() / (RAND_MAX));
    libTimer.resetTimer(r); //ajustar valor de tempo
}

void WSN_ComponentsAgent::TimerTadv(double min, double max) {
    int r = ((double) rand() / (RAND_MAX));
    r = (r % ((int) max + 1)) + min;
    printf("r:%d\n", r);
    libTimer.resetTimer(r*0.03+0.0001);
}

void WSN_ComponentsAgent::ResetTimer() {
	//libTimer.resched(CURRENT_TIME + compSensor->getNumSensors());
}

void WSN_ComponentsAgent::TimerHandle(RoundCmd roundCmd) {
	SensorDataParams sp;
	MsgParam newp;
	Packet* pkt = getNewPkt();
	WSN_Components_Message param(pkt);
	param.setId(compSensor->getSensorId());
    double r = ((double) rand() / (RAND_MAX));

	switch (roundCmd) {
		case DISCOVER_NEIGHBORS:
		{
			param.setMsgId(SENSOR_ID);

			newp.size = 1;
			sp.id = param.getId(); 
            sp.energia = 2;

			newp.msgParam[0] = sp;

			param.getHdrWsnComp()->msgParams = newp;
  
            round = ACK_DISCOVER_NEIGHBORS;
			SendPkt(SENSOR_ID, &param);
            libTimer.resetTimer(9+3*r*0.3);
		}
			break;
		case ACK_DISCOVER_NEIGHBORS:
		{
			param.setMsgId(ACK_SENSOR_ID);

			int i = 0;
            vector<SensorDataParams> lista = compSensor->getVecRecvProbeMsg();

			for (int j = 0; j< lista.size(); j++) {
				sp.id = lista.at(j).id;  //  (*x).id;
				sp.coordX = lista.at(j).coordX;
				sp.coordY = lista.at(j).coordY;
				sp.coordZ = lista.at(j).coordZ;
                sp.energia = lista.at(j).energia;

				newp.msgParam[i] = sp;
				i++;
			}
            newp.size = lista.size();
			param.getHdrWsnComp()->msgParams = newp;
			SendPkt(ACK_SENSOR_ID, &param); //}
            round = FINISH; 
		}
			break;
		case CLUSTER_FORMATION:
		{
            printf("TimerHandle CLUSTER_FORMATION %f \n", CURRENT_TIME);
			param.setMsgId(CFRM);
            
			newp.size = 1;
			sp.id = param.getId(); 
			sp.coordX = compSensor->getX();
			sp.coordY = compSensor->getY();
			sp.coordZ = compSensor->getZ();

			newp.msgParam[0] = sp;

			param.getHdrWsnComp()->msgParams = newp;
			SendPkt(CFRM, &param);
            mensagens++;
		}
			break; 

        case TREQ:
        {
            param.setMsgId(CHREQ);

			newp.size = 1;
			sp.id = param.getId(); 
			sp.coordX = compSensor->getX();
			sp.coordY = compSensor->getY();
			sp.coordZ = compSensor->getZ();
            sp.reading = compSensor->getReadings();
			newp.msgParam[0] = sp;

			param.getHdrWsnComp()->msgParams = newp;
			SendPkt(CHREQ, &param);
            mensagens++;
            //TimerTwait();
            //round = TWAIT;
        }
        break;
        case TADV:
        {
            param.setMsgId(CHADV);

			newp.size = 1;
			sp.id = param.getId(); 
			sp.coordX = compSensor->getX();
			sp.coordY = compSensor->getY();
			sp.coordZ = compSensor->getZ();
            sp.pID = compSensor->pID;
			newp.msgParam[0] = sp;

			param.getHdrWsnComp()->msgParams = newp;
			SendPkt(CHADV, &param);
            mensagens++;
        }
        break;
        case TEXT:
        {
            param.setMsgId(CEXT);

			newp.size = 1;
			sp.id = param.getId(); 
			sp.coordX = compSensor->getX();
			sp.coordY = compSensor->getY();
			sp.coordZ = compSensor->getZ();
            sp.reading = compSensor->getCHReading();
			newp.msgParam[0] = sp;

			param.getHdrWsnComp()->msgParams = newp;
			SendPkt(CEXT, &param);
            mensagens++;
        }
        break;
        case TWAIT:
        {
            if (lastMsg != CHADV) 
            {
                param.setMsgId(CHADV);

			    newp.size = 1;
			    sp.id = param.getId(); 
			    sp.coordX = compSensor->getX();
			    sp.coordY = compSensor->getY();
			    sp.coordZ = compSensor->getZ();

			    newp.msgParam[0] = sp;

			    param.getHdrWsnComp()->msgParams = newp;
			    SendPkt(CHADV, &param);
                mensagens++;
            }
        }
        break;
	}
}

void WSN_Timer::handle(Event* /*e*/) {
	WSN_ComponentsAgent* agent = dynamic_cast<WSN_ComponentsAgent*>(a_);
    agent->TimerHandle(agent->round);
}

template void WSN_Timer::initTimer(double);
template void WSN_Timer::resetTimer(double);
