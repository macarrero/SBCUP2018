#include <string>
#include "componentsDCSSC.h"
#include "componentsDCSSCCM.h"

using namespace std;

#define CURRENT_TIME    Scheduler::instance().clock()

WSN_ComponentsCM::WSN_ComponentsCM() {}

WSN_ComponentsCM::WSN_ComponentsCM(Agent *agent) {
	this->agent_ = dynamic_cast<WSN_ComponentsAgent*>(agent);
}

void WSN_ComponentsCM::setAgent(Agent *agent) {
	this->agent_ = dynamic_cast<WSN_ComponentsAgent*>(agent);
	compLib = new WSN_ComponentsLib();
}

template <class K, class V> void WSN_ComponentsCM::JoinCluster(std::map<K, V> similaridade) {
	WSN_ComponentsAgent* agent = dynamic_cast<WSN_ComponentsAgent*>(agent_);
	Packet* pkt = agent->getNewPkt();
	WSN_Components_Message param(pkt);
	MsgParam newp;
	SensorDataParams sp;
    double s = similaridade.at("K");

	printf("No %d Role %d JoinCluster (%f)\n", agent->getCompSensor()->getSensorId(), agent->getCompSensor()->role, CURRENT_TIME);

    if (s <= agent->getCompSensor()->threshold) //se altamente correlacionados
    {
        printf("Altamente correlacionados\n");
        if (agent->getCompSensor()->role == GWR) 
        {
            if (sp.pID == agent->getCompSensor()->getSensorId())
            {
                agent->getCompSensor()->role = GW;
                printf("%d virou GW\n", agent->getCompSensor()->getSensorId());
                agent->getCompSensor()->setCHReading(sp.reading);
                agent->TimerText();
                agent->round = TEXT;
            }                        
            else 
            {
                printf("%d virou CM\n", agent->getCompSensor()->getSensorId());
                agent->getCompSensor()->role = CM;
                agent->getCompSensor()->setCHReading(sp.reading);
                agent->TimerText();
                agent->round = TEXT;
            }
        }
        else {
            agent->getCompSensor()->role = CM;
            printf("%d virou CM\n", agent->getCompSensor()->getSensorId());
            agent->getCompSensor()->setCHReading(sp.reading);
            agent->TimerText();
            agent->round = TEXT;
        }
    }                
    else
    {
        agent->getCompSensor()->role = GWR;
        printf("%d virou GWR\n", agent->getCompSensor()->getSensorId());
        agent->TimerTreq();
        agent->round = TREQ;
    }			
 }

template void WSN_ComponentsCM::JoinCluster(std::map<string, double>);
