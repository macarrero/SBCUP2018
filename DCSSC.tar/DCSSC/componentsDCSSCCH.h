#ifndef _WSN_COMPONENTS_LCA_CH_
#define _WSN_COMPONENTS_LCA_CH_

#include <mobilenode.h>
#include "agent.h"
#include "packet.h"
#include "address.h"
#include "tclcl.h"
#include "ip.h"
#include <map>
#include "componentsLib.h"

using namespace std;

class WSN_ComponentsCH;

class WSN_ComponentsCH {
public:
	WSN_ComponentsCH();
	WSN_ComponentsCH(Agent *);

	template <typename K, typename V> void SelectCH(std::map<K, V>);
	void setAgent(Agent *);

protected:
	Agent *agent_;
	Packet *pkt;
	MobileNode *node;
	Trace *tracetarget;

private:
	WSN_ComponentsLib *compLib;

};

#endif
